
/* for amtega16 */

/*void serialbegin(unsigned int BAUD, unsigned int FOSC)
{
	          // unsigned int MYUBRR=((((FOSC*1000000)/16))/BAUD)-1;
	           //UBRRH = (MYUBRR >> 8);
	        //   UBRRL = 103;
	           
	          	 UCSRB=0x18;
	          	 UCSRC=0x86;
				 UCSRB |= (1 << RXCIE);       
	          	 UBRRL=103;
	
}
char serialread()
{
	while(!(UCSRA & (1<<RXC)));
	return UDR;
}
void serialwrite(unsigned char ch)
{
	UDR=ch;
	while(!(UCSRA & (1<<UDRE)));
}*/

/* for atmega328 */

void serialbegin(unsigned int BAUD, unsigned int FOSC)
{
	unsigned int MYUBRR=((((FOSC*1000000)/16))/BAUD)-1;
	UBRR0H = (MYUBRR >> 8);
	UBRR0L = MYUBRR;
	
	UCSR0B |= (1 << RXEN0) | (1 << TXEN0);      // Enable receiver and transmitter
	UCSR0B |= (1 << RXCIE0);                    // Enable reciever interrupt
	UCSR0C |= (1 << UCSZ01) | (1 << UCSZ00);    // Set frame: 8data, 1 stp
	
}
char serialread()
{
	while(!(UCSR0A & (1<<RXC0)));
	return UDR0;
}
void serialwrite(unsigned char ch)
{
	UDR0=ch;
	while(!(UCSR0A & (1<<UDRE0)));
}

void serialprintln(char *str)
{
	serialprint(str);
	serialprint("\r\n");
}

void serialprint(char *str)
{
	while(*str)
	{
		serialwrite(*str);
		str++;
	}
}


