#include <avr/io.h>
#include <stdint.h> 
#include <avr/interrupt.h>
#include <string.h>
#include "serial_header.h"
#include "lcd_header.h"



//#define sensor PA0
#define sensor PB1


char *pvt_key="gzBw6x6Nx6Io2qd9Mlq5";
char *public_key="Jxr64n4Kn4Ir4KWpQXKL";
static char postUrl[200];

char *text,mytext[4];
unsigned char  a = 0, b = 0,d = 0,t1 = 0,t2 = 0,
rh1 = 0,rh2 = 0,sum = 0;

char temperature[3];
char humidity[3];

int i=0;
char rec[100];
char ReceivedChar=0;

/*void StartSignal()
{
	DDRA|= 1<<sensor;    //Configure RD2 as output
	PORTA&= ~(1<<sensor);    //RD2 sends 0 to the sensor
	_delay_ms(18);
	PORTA|=1<<sensor;    //RD2 sends 1 to the senso
	DDRA&=~(1<<sensor);
	PORTA&=~(1<<sensor);
}

void CheckResponse()
{
	a = 0;
	_delay_us(40);
	while((PINA&(1<<sensor)));
	if(!(PINA&(1<<sensor)))
	{
		_delay_us(80);
		if (PINA&(1<<sensor))
		{
			a = 1;
			_delay_us(80);
		}
	}
}
void ReadData()
{
	for(b=0;b<8;b++)
	{
		while(!(PINA&(1<<sensor))); //Wait until PORTD.F2 goes HIGH
		_delay_us(40);
		if(!(PINA&(1<<sensor)))
		d&=~(1<<(7-b));  //Clear bit (7-b)
		else
		{
			d|= (1<<(7-b));               //Set bit (7-b)
			while(PINA&(1<<sensor));
		}
		//Wait until PORTD.F2 goes LOW
	}
} */

void StartSignal()
{
	DDRB|= 1<<sensor;    //Configure RD2 as output
	PORTB&= ~(1<<sensor);    //RD2 sends 0 to the sensor
	_delay_ms(18);
	PORTB|=1<<sensor;    //RD2 sends 1 to the senso
	DDRB&=~(1<<sensor);
	PORTB&=~(1<<sensor);
}

void CheckResponse()
{
	a = 0;
	_delay_us(40);
	while((PINB&(1<<sensor)));
	if(!(PINB&(1<<sensor)))
	{
		_delay_us(80);
		if (PINB&(1<<sensor))
		{
			a = 1;
			_delay_us(80);
		}
	}
}
void ReadData()
{
	for(b=0;b<8;b++)
	{
		while(!(PINB&(1<<sensor))); //Wait until PORTD.F2 goes HIGH
		_delay_us(40);
		if(!(PINB&(1<<sensor)))
		d&=~(1<<(7-b));  //Clear bit (7-b)
		else
		{
			d|= (1<<(7-b));               //Set bit (7-b)
			while(PINB&(1<<sensor));
		}
		//Wait until PORTD.F2 goes LOW
	}
}
 
void show()
{
	if(a == 1)
	{
		// i=0;
		ReadData();
		rh1 =d;
		ReadData();
		rh2 =d;
		ReadData();
		t1 =d;
		ReadData();
		t2 =d;
		ReadData();
		sum = d;
		if(sum == rh1+rh2+t1+t2)
		{
			lcdcmd(1);
			text = "Temp:  .0C";
			lcdprint(text);
			lcdcmd(192);
			text = "Humidity:  .0%";
			lcdprint(text);
			sprintf(temperature,"%d",t1);
			lcdcmd(0x85);
			lcdprint(temperature);
			sprintf(humidity,"%d",rh1);
			lcdcmd(0xc9);
			lcdprint(humidity);
		}
		else
		{
			lcdcmd(1);
			lcdprint("Check sum error");
		}
	}
	
	else
	{
		lcdcmd(1);
		lcdprint("No response");
		lcdcmd(192);
		lcdprint("from the sensor");
	}
}

//ISR(USART_RXC_vect)
ISR(USART_RX_vect)
{
	ReceivedChar = UDR0;                       // Read data from the RX buffer
	rec[i++]=ReceivedChar;                      // Write the data to the TX buffer
}



void get_ip()
{
	char IP[16];
	char ch=0,j=0;
	char flag=0;
	while(flag==0)
	{
		i=0;
		serialprintln("AT+CIFSR");
		_delay_ms(2000);
		 if(i>0)
		 {
		   for(j=0;j<i;j++)
		   {
			 lcdcmd(1);
			 lcdprint("Wait....");
			 if(rec[j]=='S' && rec[j+1]=='T' && rec[j+2]=='A' && rec[j+3]=='I' && rec[j+4]=='P')
			 {
				    j=j+6;
					int n=0;
					while(i!=j)
					{
					  while(rec[j]!='+')
				      {
						  IP[n++]=rec[j++];
					  }
					  flag=1;
					  break;
			        }
			}
		}
	}
   }	
   lcdcmd(1);
	lcdprint("IP:");
	lcdprint(IP);
	lcdcmd(192);
	lcdprint("Port:");
	lcdprint(80);
	i=0;
	_delay_ms(5000);
}

void send(char *str, unsigned int time)
{
	while(1)
	{
		int j=0,temp=0;
		i=0;
		serialprintln(str);
		lcdcmd(1);
		lcdprint(str);
		 for(int t=0;t<time+2000;t++)
		 _delay_ms(1);
		//int lenth= strlen_P(rec);
		 if(i>0)
		 {
			for(j=0;j<i;j++)
			{
			  if(rec[j]=='O' && rec[j+1]=='K')
			  {
			   lcdcmd(192);
			   lcdprint("OK");
			   temp=1;
			   _delay_ms(1000);
			   i=0;
			   break;
			  }			   
			  
			  else if(rec[j]=='E' && rec[j+1]=='R' && rec[j+2]=='R' && rec[j+3]=='O' && rec[j+4]=='R')
			  {
				lcdcmd(192);
			    lcdprint("Error");
				_delay_ms(1000);
				i=0;
			  }				
			}			  
		 }
		 if(temp==1)
		 break;
		
	}		  
}

void connect_wifi()
{
          send("AT",1000);	
		//  send("AT+RST",5000);
		//  send("ATE0",1000);
	      send("AT+CWMODE=1",1000);
	    //  send("AT+CWQAP",1000);
		//  lcdcmd(1);
		  lcdprint("Connecting WIFI");
		  send("AT+CWJAP=\"1st floor\",\"muda1884\"",10000);
		 // lcdcmd(1);
		 // lcdprint("Getting IP");
		 // _delay_ms(1000);
	     // get_ip();
		 // send("AT+CIPMUX=1",1000);
		 // send("AT+CIPSERVER=1,80",1000);
}

void httpGet(char * ip, char *path, int port)
{
	int resp;
	port=80;
	//atHttpGetCmd = "GET /";
	//atHttpGetCmd+=path;
	//atHttpGetCmd+=" HTTP/1.0\r\n\r\n";
	//AT+CIPSTART="TCP","192.168.20.200",80
	//char *atTcpPortConnectCmd = "AT+CIPSTART=\"TCP\",\""+ip+"\","+port+"";
	
	
	serialprint("AT+CIPSTART=\"TCP\",\"");
	serialprint(ip);
	serialprintln("\",80");
	_delay_ms(1000);
	//send(atTcpPortConnectCmd,2000);

	int len = strlen(path);
	char buff[3];
	//AT+CIPSEND=40
	char *atSendCmd = "AT+CIPSEND=";
	sprintf(buff,"%d",len);
	//atSendCmd+=buff;
	serialprint(atSendCmd);
	serialprintln(buff);
	//send(atSendCmd,2000);
	//GET /invoice/ HTTP/1.0\r\n\r\n
		serialprint("GET /");
		serialprint(path);
		serialprintln(" HTTP/1.0\r\n\r\n");
		
	//send(atHttpGetCmd,2000);
}

int main( void )
{
	int z=0;
	DDRD=0xfE;
	DDRB=0xff;
	DDRB|=1<<PB5;
    lcd_init();
    serialbegin(9600,16);    // baad rate and frequency in MHz
	//serialprint("System Ready");
	sei();
	//connect_wifi();
	lcdprint("System Ready");
	_delay_ms(1000);
	//DDRB= 0xfD;        //Configure PORTB as output
	while(1)
	{
   	 lcdcmd(1);
   	 StartSignal();
   	 CheckResponse();
   	 show();
	 if(z==5)
	 {
		 connect_wifi();
	    float temp=t1;
	    float humid=rh1;
	    long pressure=10;
	    char tempStr[8];
	    char humidStr[8];
	    char presStr[8];
	    dtostrf(temp, 5, 3, tempStr);
	    dtostrf(humid, 5, 3, humidStr);
	    dtostrf(pressure, 5, 3, presStr);

    sprintf(postUrl, "input/%s?private_key=%s&humidity=%s&temp=%s",public_key, pvt_key, humidStr,tempStr);
    httpGet("data.sparkfun.com", postUrl, 80);
	  _delay_ms(100);
	  serialprintln("AT+CIPCLOSE=0");
	  _delay_ms(2000);
	  z=0;
	 }		
	 _delay_ms(2000);
	 z++;
	}
}