#define F_CPU 16000000ul
#include <util/delay.h>


/*#define rs PB0
#define en PB2

void cmnd()
{
	PORTB&=(~(1<<rs));
	PORTB|=(1<<en);
	_delay_ms(5);
	PORTB&=(~(1<<en));
}
void lcdcmd(char ch)
{
	PORTB=ch & 0xF0;
	cmnd();
	PORTB=(ch<<4) & 0xf0;
	cmnd();
}
void lcd_init()
{
	PORTB&=~(1<<PB1);
	lcdcmd(0x02);
	lcdcmd(0x28);
	lcdcmd(0x0e);
	lcdcmd(0x01);
}
void data()
{
	PORTB|=(1<<rs);
	PORTB|=(1<<en);
	_delay_ms(5);
	PORTB&=(~(1<<en));
}
void lcddata(char ch)
{
	PORTB=ch & 0xF0;
	data();
	PORTB=(ch<<4) & 0xf0;
	data();
}
void lcdprint(char *str)
{
	while(*str)
	{
		lcddata(*str);
		str++;
	}
}*/

#define rs PD2
#define en PD3

void cmnd()
{
	PORTD&=(~(1<<rs));
	PORTD|=(1<<en);
	_delay_ms(5);
	PORTD&=(~(1<<en));
}
void lcdcmd(char ch)
{
	PORTD=ch & 0xF0;
	cmnd();
	PORTD=(ch<<4) & 0xf0;
	cmnd();
}
void lcd_init()
{
	lcdcmd(0x02);
	lcdcmd(0x28);
	lcdcmd(0x0e);
	lcdcmd(0x01);
}
void data()
{
	PORTD|=(1<<rs);
	PORTD|=(1<<en);
	_delay_ms(5);
	PORTD&=(~(1<<en));
}
void lcddata(char ch)
{
	PORTD=ch & 0xF0;
	data();
	PORTD=(ch<<4) & 0xf0;
	data();
}
void lcdprint(char *str)
{
	while(*str)
	{
		lcddata(*str);
		str++;
	}
}  
